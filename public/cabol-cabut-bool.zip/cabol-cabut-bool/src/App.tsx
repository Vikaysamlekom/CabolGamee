import { useCallback, useEffect, useRef, useState } from 'react';
import { CabolGame, HudSnapshot, WorldPopup } from './game/game';
import { soundEngine } from './game/audio';
import {
  getDefaultSave,
  getUpgradeCost,
  loadSaveData,
  persistSaveData,
  SaveData,
  SKINS,
  UPGRADES,
  UpgradeKey,
} from './game/shop';
import {
  GameEndResult,
  GameplayHud,
  MainMenuOverlay,
  PauseModal,
  ResultModal,
  SettingsModal,
  ShopModal,
} from './components/UI';

const INITIAL_HUD: HudSnapshot = {
  mode: 'menu',
  level: 1,
  levelName: 'Kebun Pemula',
  score: 0,
  targetScore: 400,
  timeLeft: 120,
  combo: 0,
  maxCombo: 0,
  comboTimerRatio: 0,
  coinsEarned: 0,
  grassPulled: 0,
  hasBoss: false,
  bossDefeated: false,
  bossHp: 0,
  bossMaxHp: 10,
  targetGrass: null,
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<CabolGame | null>(null);

  const [save, setSave] = useState<SaveData>(() => loadSaveData());
  const [selectedLevel, setSelectedLevel] = useState<number>(() => loadSaveData().highestUnlockedLevel);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [popups, setPopups] = useState<WorldPopup[]>([]);
  const [showShop, setShowShop] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [endResult, setEndResult] = useState<GameEndResult | null>(null);

  const saveRef = useRef(save);
  saveRef.current = save;

  const updateSave = useCallback((updater: (prev: SaveData) => SaveData) => {
    setSave((prev) => {
      const next = updater(prev);
      persistSaveData(next);
      gameRef.current?.updateSaveData(next);
      return next;
    });
  }, []);

  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    soundEngine.setSettings(saveRef.current.settings.sfxEnabled, saveRef.current.settings.musicEnabled);

    const game = new CabolGame(mount, saveRef.current, {
      onHudUpdate: (snapshot) => {
        setHud(snapshot);
      },
      onPopup: (popup) => {
        setPopups((prev) => [...prev.slice(-8), popup]);
        window.setTimeout(() => {
          setPopups((prev) => prev.filter((item) => item.id !== popup.id));
        }, 850);
      },
      onGameEnd: (result) => {
        setEndResult(result);
        updateSave((prev) => {
          const nextUnlocked =
            result.victory && result.level >= prev.highestUnlockedLevel
              ? Math.min(5, result.level + 1)
              : prev.highestUnlockedLevel;
          return {
            ...prev,
            coins: prev.coins + result.coinsEarned,
            highScore: Math.max(prev.highScore, result.score),
            highestUnlockedLevel: nextUnlocked,
          };
        });
      },
      onTogglePauseRequest: () => {
        setHud((curr) => {
          const nextPaused = curr.mode === 'playing';
          gameRef.current?.setPaused(nextPaused);
          return curr;
        });
      },
    });

    gameRef.current = game;
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, [updateSave]);

  const handlePlay = (levelToPlay = selectedLevel) => {
    setEndResult(null);
    setShowShop(false);
    setShowSettings(false);
    setSelectedLevel(levelToPlay);
    gameRef.current?.startLevel(levelToPlay);
  };

  const handleBuyUpgrade = (key: UpgradeKey) => {
    const cfg = UPGRADES.find((u) => u.key === key);
    if (!cfg) return;
    const currentLvl = save.upgrades[key];
    if (currentLvl >= cfg.maxLevel) return;
    const cost = getUpgradeCost(cfg, currentLvl);
    if (save.coins < cost) return;

    soundEngine.playCoin();
    updateSave((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      upgrades: {
        ...prev.upgrades,
        [key]: prev.upgrades[key] + 1,
      },
    }));
  };

  const handleBuyOrEquipSkin = (skinId: string) => {
    const skin = SKINS.find((s) => s.id === skinId);
    if (!skin) return;
    const owned = save.ownedSkins.includes(skinId);

    if (owned) {
      soundEngine.playUiClick();
      updateSave((prev) => ({ ...prev, equippedSkin: skinId }));
      return;
    }

    if (save.coins < skin.cost) return;
    soundEngine.playCoin();
    updateSave((prev) => ({
      ...prev,
      coins: prev.coins - skin.cost,
      ownedSkins: [...prev.ownedSkins, skinId],
      equippedSkin: skinId,
    }));
  };

  const handleToggleSetting = (key: 'sfxEnabled' | 'musicEnabled' | 'cameraShake') => {
    updateSave((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        [key]: !prev.settings[key],
      },
    }));
  };

  const handleResetProgress = () => {
    const def = getDefaultSave();
    persistSaveData(def);
    setSave(def);
    setSelectedLevel(1);
    gameRef.current?.updateSaveData(def);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-sky-300">
      {/* Isolated WebGL Viewport Container */}
      <div ref={canvasMountRef} className="absolute inset-0 h-full w-full" />

      {/* Main Menu */}
      {hud.mode === 'menu' && (
        <MainMenuOverlay
          save={save}
          selectedLevel={selectedLevel}
          onSelectLevel={setSelectedLevel}
          onPlay={() => handlePlay(selectedLevel)}
          onOpenShop={() => setShowShop(true)}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {/* Active Gameplay HUD */}
      {(hud.mode === 'playing' || hud.mode === 'paused') && (
        <GameplayHud
          hud={hud}
          popups={popups}
          onJoystickMove={(x, y) => gameRef.current?.setJoystick(x, y)}
          onPull={() => gameRef.current?.triggerPull()}
          onPause={() => gameRef.current?.setPaused(true)}
          onFinishEarly={() => gameRef.current?.finishLevelNow()}
        />
      )}

      {/* Pause Modal */}
      {hud.mode === 'paused' && (
        <PauseModal
          level={hud.level}
          onResume={() => gameRef.current?.setPaused(false)}
          onRestart={() => handlePlay(hud.level)}
          onMainMenu={() => {
            setEndResult(null);
            gameRef.current?.returnToMenu();
          }}
        />
      )}

      {/* Victory / Game Over Modal */}
      {endResult && (hud.mode === 'victory' || hud.mode === 'gameover') && !showShop && (
        <ResultModal
          result={endResult}
          onNextLevel={() => handlePlay(Math.min(5, endResult.level + 1))}
          onRestart={() => handlePlay(endResult.level)}
          onMainMenu={() => {
            setEndResult(null);
            gameRef.current?.returnToMenu();
          }}
          onOpenShop={() => setShowShop(true)}
        />
      )}

      {/* Shop Modal */}
      {showShop && (
        <ShopModal
          save={save}
          onBuyUpgrade={handleBuyUpgrade}
          onBuyOrEquipSkin={handleBuyOrEquipSkin}
          onClose={() => setShowShop(false)}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          save={save}
          onToggleSetting={handleToggleSetting}
          onResetProgress={handleResetProgress}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}

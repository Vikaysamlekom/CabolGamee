# CABOL – Cabut Bool (3D Funny Casual Game)

Game browser komedi kasual 3D berbasis Three.js, React, TypeScript, dan Tailwind CSS.

## Cara Menjalankan di Komputer Lokal

1. Pastikan **Node.js** (v18+) sudah terpasang.
2. Ekstrak file ZIP ini ke sebuah folder.
3. Buka terminal di folder tersebut, lalu jalankan:

```bash
npm install
npm run dev
```

4. Buka `http://localhost:3000` di browser.

## Kontrol Game

- **Desktop**: `WASD` atau Tombol Panah untuk bergerak, `Spasi` untuk **CABUT**, `ESC` untuk **Pause**.
- **Mobile**: Virtual Joystick di kiri bawah dan tombol **CABUT!** di kanan bawah.
